package com.floatmaster.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var listArea: View? = null
    private var collapsed = false
    private val channelId = "floatmaster_panel"

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(7, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "FloatMaster", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 8, Intent(this, FloatingPanelService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("FloatMaster ativo")
            .setContentText("Toque nos aplicativos do painel para abri-los.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fechar painel", stop)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") stopSelf()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(9))
            background = rounded(Color.rgb(17, 25, 43), dp(20))
            elevation = dp(16).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(7), dp(8))
        }
        val heading = TextView(this).apply {
            text = "◈  FLOATMASTER"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(3), dp(8), 0, dp(8))
        }
        val minimize = smallButton("−")
        val close = smallButton("×")
        header.addView(heading, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(minimize, LinearLayout.LayoutParams(dp(38), dp(38)))
        header.addView(close, LinearLayout.LayoutParams(dp(38), dp(38)))
        root.addView(header)

        val hint = TextView(this).apply {
            text = "  APLICATIVOS INSTALADOS"
            textSize = 10f
            setTextColor(Color.rgb(133, 158, 205))
            setPadding(dp(12), dp(5), dp(8), dp(8))
        }
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), 0, dp(9), 0)
        }
        val apps = packageManager.getInstalledApplications(0)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }

        for (app in apps) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(7), dp(10), dp(7))
                background = rounded(Color.rgb(30, 43, 68), dp(12))
                val lp = LinearLayout.LayoutParams(-1, dp(52))
                lp.bottomMargin = dp(6)
                layoutParams = lp
            }
            val icon = ImageView(this).apply {
                setImageDrawable(packageManager.getApplicationIcon(app))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            val name = TextView(this).apply {
                text = packageManager.getApplicationLabel(app).toString()
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(dp(11), 0, 0, 0)
                maxLines = 1
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(30), dp(30)))
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            row.setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { startActivity(launch) } catch (_: Exception) {
                        Toast.makeText(this, "Não foi possível abrir este aplicativo.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            list.addView(row)
        }
        if (apps.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nenhum aplicativo disponível."
                setTextColor(Color.LTGRAY)
                setPadding(dp(12), dp(20), dp(12), dp(20))
            })
        }
        scroll.addView(list)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(hint)
            addView(scroll, LinearLayout.LayoutParams(-1, dp(390)))
        }
        listArea = content
        root.addView(content)

        val params = WindowManager.LayoutParams(
            dp(292), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(10); y = dp(90) }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        heading.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
                    true
                }
                else -> false
            }
        }
        minimize.setOnClickListener {
            collapsed = !collapsed
            content.visibility = if (collapsed) View.GONE else View.VISIBLE
            minimize.text = if (collapsed) "+" else "−"
            try { wm.updateViewLayout(root, params) } catch (_: Exception) { }
        }
        close.setOnClickListener { stopSelf() }
        panel = root
        try { wm.addView(root, params) } catch (_: Exception) { stopSelf() }
    }

    private fun smallButton(label: String) = TextView(this).apply {
        text = label
        textSize = 24f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(39, 55, 84), dp(11))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        panel = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
