package com.floatmaster.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 15, 29)
        window.navigationBarColor = Color.rgb(10, 15, 29)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(24))
            setBackgroundColor(Color.rgb(10, 15, 29))
        }
        root.addView(TextView(this).apply {
            text = "FLOATMASTER"
            textSize = 27f
            letterSpacing = .08f
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Seus aplicativos sempre à mão"
            textSize = 15f
            setTextColor(Color.rgb(153, 170, 203))
            setPadding(0, dp(7), 0, dp(24))
        })

        val card = TextView(this).apply {
            text = "Abra o painel sobre qualquer tela, escolha um aplicativo e mova o painel pela tela. O modo de janela de cada aplicativo depende dos recursos permitidos pelo Android/HyperOS."
            textSize = 14f
            setTextColor(Color.rgb(220, 228, 244))
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(Color.rgb(25, 35, 57), dp(16))
        }
        root.addView(card)

        val permission = makeButton("1  •  Permitir sobre outros aplicativos")
        permission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        root.addView(permission)

        val start = makeButton("2  •  Iniciar painel FloatMaster")
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Primeiro permita aparecer sobre outros apps.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
                }
                startPanel()
            }
        }
        root.addView(start)

        root.addView(TextView(this).apply {
            text = "Dica para HyperOS: se um aplicativo abrir em tela cheia, use a função de janela flutuante do próprio sistema, quando disponível. O FloatMaster não altera nem desbloqueia funções internas do aparelho."
            textSize = 12f
            setTextColor(Color.rgb(135, 151, 181))
            setPadding(dp(2), dp(20), dp(2), 0)
        })
        setContentView(root)
    }

    private fun startPanel() {
        val intent = Intent(this, FloatingPanelService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Painel FloatMaster iniciado", Toast.LENGTH_SHORT).show()
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(37, 99, 235), dp(14))
        val p = LinearLayout.LayoutParams(-1, dp(54))
        p.topMargin = dp(14)
        layoutParams = p
    }

    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }
}
