# FloatMaster — projeto Android atualizado

Aplicativo nativo Kotlin para Android 8+ (API 26+) que exibe um painel de atalhos sobre outros aplicativos.

## Recursos
- Painel sobreposto, arrastável e recolhível.
- Lista de aplicativos instalados com ícones e nomes.
- Abertura de aplicativos pelo painel.
- Notificação persistente com ação para encerrar o serviço.
- Interface escura adaptada para telas de celular.

## Instalação e permissões no Redmi 13C / HyperOS
1. Instale o APK compilado e abra o FloatMaster.
2. Toque em **Permitir sobre outros aplicativos** e habilite a permissão para FloatMaster.
3. Volte ao FloatMaster e toque em **Iniciar painel FloatMaster**.
4. Se o Android solicitar, permita as notificações.
5. Arraste o título do painel para movê-lo. Use **−** para recolher e **×** para fechar.

## Compilar APK
Requer Android Studio ou ambiente Android compatível, JDK 17 e Android SDK Platform 35.
1. Abra esta pasta como projeto Gradle.
2. Aguarde a sincronização.
3. Execute a tarefa `:app:assembleDebug`.
4. O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Limitações reais do Android/HyperOS
O FloatMaster é um launcher em sobreposição. Ao tocar em um aplicativo, ele solicita ao Android que o abra normalmente. Transformar arbitrariamente qualquer aplicativo de terceiros em janela livre depende do suporte do sistema e das restrições do próprio aplicativo. O FloatMaster não usa root, não altera arquivos do sistema e não contorna as proteções do HyperOS. Se o app abrir em tela cheia, use a função de janela flutuante do HyperOS quando ela estiver disponível para aquele aplicativo.

A permissão `SYSTEM_ALERT_WINDOW` é necessária para o painel. `QUERY_ALL_PACKAGES` é usada para listar os aplicativos instalados; a distribuição pela Play Store está sujeita às políticas de visibilidade de pacotes.
